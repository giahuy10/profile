$(window).bind("load", function() {
   $('#loader').remove();
   $('html').css({'overflow' : 'auto'});
});